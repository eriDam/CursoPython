# Este es un modulo con funcionkes que saludan
def saludar():
	print("Hola, te estoy saludando desde la funcion saludar del modulo de saludos")


class Saludo():
	def __init__(self):
		print("Hola, te estoy saludando desde el init de la clase saludo")	