# Al llamar el archivo como __init__.py, le indicará a python q este directorio es un  paquete yq8ue deberá ejecutar la jerarquía de modulos, 
#se debe ejecutar al principio como si fuera el init de una clase

# se podrá instalar en otros ordenadores o reutilizarlos. 
