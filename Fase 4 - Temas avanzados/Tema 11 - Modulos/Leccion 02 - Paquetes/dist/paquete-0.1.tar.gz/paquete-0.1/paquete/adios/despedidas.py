# Este es un modulo con funcionkes que despiden
def despedirse():
	print("Adios, me estoy despidiendo desde la funcion despedirse del modulo de despedidas")


class Despedida():
	def __init__(self):
		print("Adios, me estoy despidiendo desde el init de la clase Despedida")	